<div class="ps-cart"><a class="ps-cart__toggle" href="#"><span><i><?php echo e($cart->all()->count()); ?></i></span><i class="ps-icon-shopping-cart"></i></a>
    <div class="ps-cart__listing">
        <div class="ps-cart__content">
            <?php $__currentLoopData = $cart->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="ps-cart-item"><a class="ps-cart-item__close" href="#"></a>
                <div class="ps-cart-item__thumbnail"><a href="<?php echo e($item->product->permalink); ?>"></a><img src="<?php echo e($item->product->image); ?>" alt=""></div>
                <div class="ps-cart-item__content"><a class="ps-cart-item__title" href="<?php echo e($item->product->permalink); ?>l"><?php echo e($item->product->name); ?></a>
                    <p><span>Quantity:<i><?php echo e($item->quantity); ?></i></span><span>Total:<i><?php if (isset($component)) { $__componentOriginal0c41fba79d6efaa28d725317f762661e6e2fdfe4 = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\Currency::class, ['amount' => $item->quantity * $item->product->purchase_price]); ?>
<?php $component->withName('currency'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
<?php if (isset($__componentOriginal0c41fba79d6efaa28d725317f762661e6e2fdfe4)): ?>
<?php $component = $__componentOriginal0c41fba79d6efaa28d725317f762661e6e2fdfe4; ?>
<?php unset($__componentOriginal0c41fba79d6efaa28d725317f762661e6e2fdfe4); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?></i></span></p>
                </div>
            </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
        <div class="ps-cart__total">
            <p>Number of items:<span><?php echo e($cart->all()->sum('quantity')); ?></span></p>
            <p>Item Total:<span><?php if (isset($component)) { $__componentOriginal0c41fba79d6efaa28d725317f762661e6e2fdfe4 = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\Currency::class, ['amount' => $cart->total()]); ?>
<?php $component->withName('currency'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
<?php if (isset($__componentOriginal0c41fba79d6efaa28d725317f762661e6e2fdfe4)): ?>
<?php $component = $__componentOriginal0c41fba79d6efaa28d725317f762661e6e2fdfe4; ?>
<?php unset($__componentOriginal0c41fba79d6efaa28d725317f762661e6e2fdfe4); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?></span></p>
        </div>
        <div class="ps-cart__footer"><a class="ps-btn" href="<?php echo e(route('checkout')); ?>">Check out<i class="ps-icon-arrow-left"></i></a></div>
    </div>
</div><?php /**PATH E:\Maan-Laravel\store\resources\views/components/cart-menu.blade.php ENDPATH**/ ?>