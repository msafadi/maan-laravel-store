<?php if(session()->has('status')): ?>
<div class="alert alert-info">
    <?php echo e(session()->get('status')); ?>

</div>
<?php endif; ?>
<?php if(session()->has('success')): ?>
<div class="alert alert-success">
    <?php echo e(session()->get('success')); ?>

</div>
<?php endif; ?>
<?php if(session()->has('error')): ?>
<div class="alert alert-danger">
    <?php echo e(session()->get('error')); ?>

</div>
<?php endif; ?><?php /**PATH E:\Maan-Laravel\store\resources\views/components/alert.blade.php ENDPATH**/ ?>