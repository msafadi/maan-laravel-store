<?php if (isset($component)) { $__componentOriginal2d335b3e8e6ae5cc62c41746c3076a345a6ceca2 = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\StoreLayout::class, []); ?>
<?php $component->withName('store-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>

    <div class="ps-content pt-80 pb-80">
        <div class="ps-container">
            <div class="ps-cart-listing">
                <table class="table ps-cart__table">
                    <thead>
                        <tr>
                            <th>All Products</th>
                            <th>Price</th>
                            <th>Quantity</th>
                            <th>Total</th>
                            <th></th>
                        </tr>
                    </thead>
                    <tbody>
                        
                        <?php $__currentLoopData = $cart; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            
                        <tr>
                            <td><a class="ps-product__preview" href="<?php echo e($item->product->permalink); ?>"><img class="mr-15" src="<?php echo e($item->product->image); ?>" height="60" alt=""> <?php echo e($item->product->name); ?></a></td>
                            <td><?php if (isset($component)) { $__componentOriginal0c41fba79d6efaa28d725317f762661e6e2fdfe4 = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\Currency::class, ['amount' => $item->product->purchase_price]); ?>
<?php $component->withName('currency'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
<?php if (isset($__componentOriginal0c41fba79d6efaa28d725317f762661e6e2fdfe4)): ?>
<?php $component = $__componentOriginal0c41fba79d6efaa28d725317f762661e6e2fdfe4; ?>
<?php unset($__componentOriginal0c41fba79d6efaa28d725317f762661e6e2fdfe4); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?></td>
                            <td>
                                <div class="form-group--number">
                                    <button class="minus"><span>-</span></button>
                                    <input class="form-control" type="text" value="<?php echo e($item->quantity); ?>">
                                    <button class="plus"><span>+</span></button>
                                </div>
                            </td>
                            <td><?php if (isset($component)) { $__componentOriginal0c41fba79d6efaa28d725317f762661e6e2fdfe4 = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\Currency::class, ['amount' => $item->quantity * $item->product->purchase_price]); ?>
<?php $component->withName('currency'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
<?php if (isset($__componentOriginal0c41fba79d6efaa28d725317f762661e6e2fdfe4)): ?>
<?php $component = $__componentOriginal0c41fba79d6efaa28d725317f762661e6e2fdfe4; ?>
<?php unset($__componentOriginal0c41fba79d6efaa28d725317f762661e6e2fdfe4); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?></td>
                            <td>
                                <div class="ps-remove"></div>
                            </td>
                        </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>
                <div class="ps-cart__actions">
                    <div class="ps-cart__promotion">
                        <div class="form-group">
                            <div class="ps-form--icon"><i class="fa fa-angle-right"></i>
                                <input class="form-control" type="text" placeholder="Promo Code">
                            </div>
                        </div>
                        <div class="form-group">
                            <a href="<?php echo e(url('/')); ?>" class="ps-btn ps-btn--gray">Continue Shopping</a>
                        </div>
                    </div>
                    <div class="ps-cart__total">
                        <h3>Total Price: <span> <?php if (isset($component)) { $__componentOriginal0c41fba79d6efaa28d725317f762661e6e2fdfe4 = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\Currency::class, ['amount' => $total]); ?>
<?php $component->withName('currency'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
<?php if (isset($__componentOriginal0c41fba79d6efaa28d725317f762661e6e2fdfe4)): ?>
<?php $component = $__componentOriginal0c41fba79d6efaa28d725317f762661e6e2fdfe4; ?>
<?php unset($__componentOriginal0c41fba79d6efaa28d725317f762661e6e2fdfe4); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?> </span></h3><a class="ps-btn" href="<?php echo e(route('checkout')); ?>">Process to checkout<i class="ps-icon-next"></i></a>
                    </div>
                </div>
            </div>
        </div>
    </div>

 <?php if (isset($__componentOriginal2d335b3e8e6ae5cc62c41746c3076a345a6ceca2)): ?>
<?php $component = $__componentOriginal2d335b3e8e6ae5cc62c41746c3076a345a6ceca2; ?>
<?php unset($__componentOriginal2d335b3e8e6ae5cc62c41746c3076a345a6ceca2); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?><?php /**PATH E:\Maan-Laravel\store\resources\views/store/cart.blade.php ENDPATH**/ ?>