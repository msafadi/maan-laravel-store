<?php if (isset($component)) { $__componentOriginal2d335b3e8e6ae5cc62c41746c3076a345a6ceca2 = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\StoreLayout::class, []); ?>
<?php $component->withName('store-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
    <div class="ps-checkout pt-80 pb-80">
        <div class="ps-container">
            <?php if($errors->any()): ?>
            <div class="alert alert-danger">
                <ul>
                    <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $message): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <li><?php echo e($message); ?></li>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </ul>
            </div>
            <?php endif; ?>
            <form class="ps-checkout__form" action="<?php echo e(route('checkout')); ?>" method="post">
                <?php echo csrf_field(); ?>
                <div class="row">
                    <div class="col-lg-8 col-md-8 col-sm-12 col-xs-12 ">
                        <div class="ps-checkout__billing">
                            <h3>Billing Detail</h3>
                            <div class="form-group form-group--inline">
                                <label>First Name<span>*</span>
                                </label>
                                <input class="form-control" name="billing_firstname" value="<?php echo e(old('billing_firstname', $user->name)); ?>" type="text">
                            </div>
                            <div class="form-group form-group--inline">
                                <label>Last Name<span>*</span>
                                </label>
                                <input class="form-control" name="billing_lastname" value="<?php echo e(old('billing_lastname', $user->name)); ?>" type="text">
                            </div>
                            <div class="form-group form-group--inline">
                                <label>Email Address<span>*</span>
                                </label>
                                <input class="form-control" name="billing_email" value="<?php echo e(old('billing_email', $user->email)); ?>" type="email">
                            </div>
                            <div class="form-group form-group--inline">
                                <label>Phone<span>*</span>
                                </label>
                                <input class="form-control" name="billing_phone" value="<?php echo e(old('billing_phone', $user->mobile)); ?>" type="text">
                            </div>
                            <div class="form-group form-group--inline">
                                <label>Address<span>*</span>
                                </label>
                                <input class="form-control" name="billing_address" value="<?php echo e(old('billing_address')); ?>" type="text">
                            </div>
                            <div class="form-group form-group--inline">
                                <label>City<span>*</span>
                                </label>
                                <input class="form-control" name="billing_city" value="<?php echo e(old('billing_city')); ?>" type="text">
                            </div>
                            <div class="form-group form-group--inline">
                                <label>Postal Code<span>*</span>
                                </label>
                                <input class="form-control" name="billing_postalcode" value="<?php echo e(old('billing_postalcode')); ?>" type="text">
                            </div>
                            <div class="form-group form-group--inline">
                                <label>Country<span>*</span>
                                </label>
                                <select class="form-control" name="billing_country">
                                    <?php $__currentLoopData = $countries; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $code => $name): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($code); ?>" <?php if($code == old('billing_country')): ?> selected <?php endif; ?>><?php echo e($name); ?></option>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </select>
                            </div>
                            <div class="form-group">
                                <div class="ps-checkbox">
                                    <input class="form-control" type="checkbox" id="cb01">
                                    <label for="cb01">Create an account?</label>
                                </div>
                            </div>
                            <h3 class="mt-40"> Addition information</h3>
                            <div class="form-group form-group--inline textarea">
                                <label>Order Notes</label>
                                <textarea class="form-control" rows="5" placeholder="Notes about your order, e.g. special notes for delivery."></textarea>
                            </div>
                        </div>
                    </div>
                    <div class="col-lg-4 col-md-4 col-sm-12 col-xs-12 ">
                        <div class="ps-checkout__order">
                            <header>
                                <h3>Your Order</h3>
                            </header>
                            <div class="content">
                                <table class="table ps-checkout__products">
                                    <thead>
                                        <tr>
                                            <th class="text-uppercase">Product</th>
                                            <th class="text-uppercase">Total</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <?php $__currentLoopData = $cart->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <tr>
                                            <td><?php echo e($item->product->name); ?> x<?php echo e($item->quantity); ?></td>
                                            <td><?php if (isset($component)) { $__componentOriginal0c41fba79d6efaa28d725317f762661e6e2fdfe4 = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\Currency::class, ['amount' => $item->quantity * $item->product->purchase_price]); ?>
<?php $component->withName('currency'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
<?php if (isset($__componentOriginal0c41fba79d6efaa28d725317f762661e6e2fdfe4)): ?>
<?php $component = $__componentOriginal0c41fba79d6efaa28d725317f762661e6e2fdfe4; ?>
<?php unset($__componentOriginal0c41fba79d6efaa28d725317f762661e6e2fdfe4); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?></td>
                                        </tr>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        <tr>
                                            <td>Order Total</td>
                                            <td><?php if (isset($component)) { $__componentOriginal0c41fba79d6efaa28d725317f762661e6e2fdfe4 = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\Currency::class, ['amount' => $cart->total()]); ?>
<?php $component->withName('currency'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
<?php if (isset($__componentOriginal0c41fba79d6efaa28d725317f762661e6e2fdfe4)): ?>
<?php $component = $__componentOriginal0c41fba79d6efaa28d725317f762661e6e2fdfe4; ?>
<?php unset($__componentOriginal0c41fba79d6efaa28d725317f762661e6e2fdfe4); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?></td>
                                        </tr>
                                    </tbody>
                                </table>
                            </div>
                            <footer>
                                <h3>Payment Method</h3>
                                <div class="form-group cheque">
                                    <div class="ps-radio">
                                        <input class="form-control" type="radio" id="rdo01" name="payment" checked>
                                        <label for="rdo01">Cheque Payment</label>
                                        <p>Please send your cheque to Store Name, Store Street, Store Town, Store State / County, Store Postcode.</p>
                                    </div>
                                </div>
                                <div class="form-group paypal">
                                    <div class="ps-radio ps-radio--inline">
                                        <input class="form-control" type="radio" name="payment" id="rdo02">
                                        <label for="rdo02">Paypal</label>
                                    </div>
                                    <ul class="ps-payment-method">
                                        <li><a href="#"><img src="images/payment/1.png" alt=""></a></li>
                                        <li><a href="#"><img src="images/payment/2.png" alt=""></a></li>
                                        <li><a href="#"><img src="images/payment/3.png" alt=""></a></li>
                                    </ul>
                                    <button type="submit" class="ps-btn ps-btn--fullwidth">Place Order<i class="ps-icon-next"></i></button>
                                </div>
                            </footer>
                        </div>
                        <div class="ps-shipping">
                            <h3>FREE SHIPPING</h3>
                            <p>YOUR ORDER QUALIFIES FOR FREE SHIPPING.<br> <a href="#"> Singup </a> for free shipping on every order, every time.</p>
                        </div>
                    </div>
                </div>
            </form>
        </div>
    </div>
 <?php if (isset($__componentOriginal2d335b3e8e6ae5cc62c41746c3076a345a6ceca2)): ?>
<?php $component = $__componentOriginal2d335b3e8e6ae5cc62c41746c3076a345a6ceca2; ?>
<?php unset($__componentOriginal2d335b3e8e6ae5cc62c41746c3076a345a6ceca2); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?><?php /**PATH E:\Maan-Laravel\store\resources\views/store/checkout.blade.php ENDPATH**/ ?>