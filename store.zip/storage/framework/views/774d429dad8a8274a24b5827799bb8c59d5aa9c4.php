<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body>
    <p style="color:midnightblue">Hello, <?php echo e($name); ?></p>
    <p>A new order created.</p>
    <p><a href="<?php echo e($url); ?>">View Order</a>
    <p>Thank you for using our application!</p>
</body>
</html><?php /**PATH E:\Maan-Laravel\store\resources\views/mails/new-order.blade.php ENDPATH**/ ?>