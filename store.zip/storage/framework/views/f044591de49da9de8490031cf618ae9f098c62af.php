<div class="dropdown az-header-notification">
    <a href="" <?php if($unread): ?> class="new" <?php endif; ?>><i class="typcn typcn-bell"></i></a>
    <div class="dropdown-menu">
        <div class="az-dropdown-header mg-b-20 d-sm-none">
            <a href="" class="az-header-arrow"><i class="icon ion-md-arrow-back"></i></a>
        </div>
        <h6 class="az-notification-title">Notifications</h6>
        <p class="az-notification-text">You have <span id="unread"><?php echo e($unread); ?></span> unread notification</p>
        <div class="az-notification-list">
            <?php $__currentLoopData = $notifications; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $notification): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <a href="<?php echo e($notification->data['link']); ?>?notify_id=<?php echo e($notification->id); ?>">
                <div class="media <?php if($notification->unread()): ?> new <?php endif; ?>">
                    <div class="az-img-user"><img src="<?php echo e(asset('assets/dashboard/img/faces/face2.jpg')); ?>" alt=""></div>
                    <div class="media-body">
                        <p><?php echo e($notification->data['body']); ?></p>
                        <span><?php echo e($notification->created_at->diffForHumans()); ?></span>
                    </div><!-- media-body -->
                </div><!-- media -->
            </a>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div><!-- az-notification-list -->
        <div class="dropdown-footer"><a href="">View All Notifications</a></div>
    </div><!-- dropdown-menu -->
</div><!-- az-header-notification --><?php /**PATH E:\Maan-Laravel\store\resources\views/components/notifications-menu.blade.php ENDPATH**/ ?>